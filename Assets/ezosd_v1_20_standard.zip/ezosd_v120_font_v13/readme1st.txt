EzOSD v1.20 firmware and v1.3 font update: 

***This readme1st.txt contains essential information about installing the v1.20 firmware and v1.3 font update for the EzOSD, please read carefully!***

The zip archive that you unpacked contains, besides this .txt file, two files:

- FontLoader_v1.3.fw
- EzOSD_v1.20_StandardVersion.fw

The proper procedure and sequence to install these is the following (using IRC tools). Both files need to be programmed in this order for the new v1.18 firmware to work:

Loading v1.3 font update:

1) Go to EzOSD tab on IRC tools
2) Press center button on EzOSD and keep pressed
3) Connect to USB
4) IRC tools should detect a EzOSD in program mode
5) Release center button
6) Click 'Update firmware'
7) Point to 'EzOSDFontLoader_v1.3.fw'
8) EzOSD will program
9) After completion leave connected
10) After a few seconds the LED start flashing rapidly
11) Disconnect after LED stops flashing rapidly

Loading v1.20 firmware update:

12) Go to EzOSD tab on IRC tools
13) Press center button on EzOSD and keep pressed
14) Connect to USB
15) IRC tools should detect a EzOSD in program mode
16) Release center button
17) Click 'Update firmware'
18) Point to 'EzOSD v1.20.fw'
19) EzOSD will program
20) After completion remove EzOSD from USB and install in plane

That completes the upgrade procedure for the new fonts and v1.18 firmware.

Goggle up and fly safe!

Team ImmersionRC