# Vortex-Configurator

Crossplatform configuration tool for ImmersionRC Vortex products

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

Install Chrome Browser

### Installing

1. Settings-Icon > More tools > Extensions
	(the 'three horizontal-bars' icon in the top-right corner)
2. Drag and drop the "crx" extension file onto the Extensions page from [step 1]
	(.crx file should likely be in your Downloads directory)
3. Install
